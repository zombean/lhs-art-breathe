//
//  JsonLiteObjCInputParams.h
//  JsonLiteObjC
//
//  Created by admin on 4/27/13.
//  Copyright (c) 2013 Andrii Mamchur. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface JsonLiteObjCInputs : XCTestCase

@end
