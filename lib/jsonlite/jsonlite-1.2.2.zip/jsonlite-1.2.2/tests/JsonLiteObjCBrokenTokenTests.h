//
//  JsonLiteObjCBrokenTokenTests.h
//  JsonLiteObjC
//
//  Created by admin on 6/22/13.
//  Copyright (c) 2013 Andrii Mamchur. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface JsonLiteObjCBrokenTokenTests : XCTestCase

@end
