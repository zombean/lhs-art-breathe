//
//  main.m
//  TwitterJsonLite
//
//  Created by Andriy Mamchur on 6/9/12.
//  Copyright 2012 soft serve. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
