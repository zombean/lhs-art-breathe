//
//  JsonLiteObjCStream.h
//  JsonLiteObjC
//
//  Created by admin on 7/12/13.
//  Copyright (c) 2013 Andrii Mamchur. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface JsonLiteObjCStream : XCTestCase{
    volatile BOOL finished;
}

@end
